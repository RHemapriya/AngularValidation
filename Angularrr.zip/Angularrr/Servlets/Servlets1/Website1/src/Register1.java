

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register1
 */
public class Register1 extends HttpServlet {

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		String username=request.getParameter("name");
		String password=request.getParameter("pass");
		String email=request.getParameter("mail");
		
			RequestDispatcher rd=request.getRequestDispatcher("Login.html");
		    rd.forward(request, response);
		    out.print("Registration successfull");
		
		
//			RequestDispatcher rd=request.getRequestDispatcher("Index.html");
//			rd.include(request, response);
//			out.print("PLEASE ENTER VALID CREDENTIALS");
		
	}

}
