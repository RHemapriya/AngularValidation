

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("RegisterServlet")
public class RegisterServlet extends HttpServlet {
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		String username=request.getParameter("name");
		String password=request.getParameter("pass");
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg412","training412");
		
		Statement stmt=conn.createStatement();
		
		ResultSet result=stmt.executeQuery("select * from gmail");

		if(result.next())
		{
			RequestDispatcher rd=request.getRequestDispatcher("Home.html");
		    rd.forward(request, response);
		    out.println("Welcome to home page "+result.getString(3));
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Index.html");
			rd.include(request, response);
			out.println("PLEASE ENTER VALID CREDENTIALS");
		}
		conn.close();}
		catch(Exception e)
		{
			System.out.println(e);
		}
			
		
	}

}
