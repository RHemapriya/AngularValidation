package jdbcCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class executeQuery {
	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg412","training412");
		
		Statement stmt=conn.createStatement();
		
		ResultSet result=stmt.executeQuery("select * from awake");
		
		while(result.next()){
	    System.out.println(result.getString("name")+" "+result.getString("fname"));
		}
		conn.close();
	}
}


