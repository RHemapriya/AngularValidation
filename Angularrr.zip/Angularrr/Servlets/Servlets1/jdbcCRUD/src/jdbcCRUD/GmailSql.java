package jdbcCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class GmailSql {
	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		
	
	Scanner scan=new Scanner(System.in);
    System.out.println("Enter the Username");
    String uname=scan.next();
    System.out.println("Enter the Password");
    String upass=scan.next();
    Class.forName("oracle.jdbc.driver.OracleDriver");
	
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg412","training412");
	
	Statement stmt=conn.createStatement();
	
	ResultSet result=stmt.executeQuery("select * from gmail");
	
//	String uu=result.getString("username");
//	String pp=result.getString("password");
	
	while(result.next()){
    
	if(uname.equals(result.getString(1)) && upass.equals(result.getString(2)))
	{
	System.out.println("Login Success");}
	else{
	System.out.println("Login failed");
	}}
	conn.close();

}
}