package jdbcCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CRUDExample {
	public static void main(String[] args) throws ClassNotFoundException,SQLException{
			//loading the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//create the connection
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg412","training412");
			//create the statement
			Statement stmt=conn.createStatement();
			//execute query 
			//boolean execute()-->ddl
			//int executeUpdate-->dml
			//ResultsetexecuteQuery-->select
			//boolean result=stmt.execute("create table Awake(name varchar2(10),fname varchar2(15))");
		    //int result=stmt.executeUpdate("insert into Awake values('Ram','Ram')");
			//int result=stmt.executeUpdate("insert into Awake values('Hare','Krishna')");
			//int result=stmt.executeUpdate("insert into Awake values('Sri','Ram')");
			//int result=stmt.executeUpdate("delete from awake where name='Sri'");
			ResultSet result=stmt.executeQuery("select * from awake");
			//close connection
			while(result.next()){
		    System.out.println(result.getString("name")+" "+result.getString("fname"));
			}
			conn.close();
		}
	}


