function add(x:number, ...y:number[]):number{
    let result=x;
    for(var i=0;i<y.length;i++){
        result=result+y[i];
    }
    return result;
}
let result1=add(2,5);
let result2=add(2,5,7);
console.log(result1);
console.log(result2);