var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
var p = new Person();
p.firstname = "Madhav";
p.lastname = "Sri";
console.log(p.firstname + " " + p.lastname);
