function f2()
{
    let a=123;
    if(a>100)
    {
        var b=234;
        console.log(a);
       // console.log(b);
    }
    console.log(b);
}
f2();