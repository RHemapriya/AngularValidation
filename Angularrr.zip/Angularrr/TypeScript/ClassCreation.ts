class Person
{
    firstname:string;
    lastname:string;
}
var p=new Person();
p.firstname="Madhav";
p.lastname="Sri";
 console.log(`${p.firstname} ${p.lastname}`);