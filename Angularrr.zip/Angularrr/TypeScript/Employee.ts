class Person
{
    private firstname:string;
    private lastname:string;
    constructor(firstname:string, lastname:string){
        this.firstname=firstname;
        this.lastname=lastname;
    }
    fullName():string{
        return this.firstname+" "+this.lastname;
    }
}
class Employee extends Person{
    id:number;
    constructor(id:number,firstname:string,lastname:string){
        super(firstname,lastname);
        this.id=id;
}
showDetails():void{
    console.log(this.id+" "+this.fullName());
}
}
let e1=new Employee(1,"Murali","Manoharan");
e1.showDetails();