var Employee = /** @class */ (function () {
    function Employee(empid, name) {
        Employee.empid = empid;
        this.name = name;
    }
    Employee.prototype.displayDetails = function () {
        return Employee.empid + " : " + this.name;
    };
    return Employee;
}());
Employee.empid = 123;
var emp = new Employee(123, "Madhav");
console.log(emp.displayDetails());
