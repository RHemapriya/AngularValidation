var num = 12;
var a1 = [1, 2, 3, 'a', true];
var x;
x = [1, 2, 3, 4];
x.push(10);
console.log(x);
for (var i in x) {
    console.log(i);
}
console.log(num);
num = x.pop();
console.log(num);
var numberList = [1, 2, 3];
var numList = [1, 2, 3];
console.log(numberList);
console.log(numList);
console.log(x);
