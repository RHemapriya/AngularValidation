function add(x) {
    var y = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        y[_i - 1] = arguments[_i];
    }
    var result = x;
    for (var i = 0; i < y.length; i++) {
        result = result + y[i];
    }
    return result;
}
var result1 = add(2, 5);
var result2 = add(2, 5, 7);
console.log(result1);
console.log(result2);
