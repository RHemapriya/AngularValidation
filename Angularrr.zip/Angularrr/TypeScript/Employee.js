var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person = /** @class */ (function () {
    function Person(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    Person.prototype.fullName = function () {
        return this.firstname + " " + this.lastname;
    };
    return Person;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(id, firstname, lastname) {
        var _this = _super.call(this, firstname, lastname) || this;
        _this.id = id;
        return _this;
    }
    Employee.prototype.showDetails = function () {
        console.log(this.id + " " + this.fullName());
    };
    return Employee;
}(Person));
var e1 = new Employee(1, "Murali", "Manoharan");
e1.showDetails();
