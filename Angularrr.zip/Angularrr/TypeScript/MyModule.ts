export class Employee{
    constructor(private firstname:string,
                private lastname:string){}
                    showDetails(){
                        return this.firstname+", "+this.lastname;
                    }
                }
                export class Student{
                    constructor(private rollNo:number,private name:string){}
                        showDetails(){
                            return this.rollNo+", "+this.name;
                        }
                    }
                

