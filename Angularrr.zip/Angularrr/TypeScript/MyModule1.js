"use strict";
exports.__esModule = true;
var MyModule_1 = require("./MyModule");
var st = new MyModule_1.Student(1, "Madhav");
var result1 = st.showDetails();
console.log("Student Details: " + result1);
var emp = new MyModule_1.Employee("Kannan", "Hello");
var result2 = emp.showDetails();
console.log("Employee Details: " + result2);
