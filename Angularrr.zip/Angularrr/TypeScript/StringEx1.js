var firstname = "International Business Machine";
var site = 'www.ibm.com';
var str = 'Hello, my name is ' + firstname + ' and my site is ' + site;
console.log(str);
var str2 = "Hello, my name is " + firstname + " and my site is " + site;
console.log(str2);
