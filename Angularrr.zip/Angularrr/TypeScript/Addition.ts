function addition(a,b)
{
    return a+b;
}
var sum=addition(2,3);
var sum1=addition("hi",3);
console.log(sum);
console.log(sum1);
 
function addition1(x:number,y:number)
{
    return x+y;
}
var summ=addition1(2,3);
console.log(summ);
function addition2(a:number,b:number,c?)
{
    return a+b+c;
}
var s1=addition2(2,3,5);
var s2=addition2(2,3);
console.log(s1);
console.log(s2);
function addition3(a,b,c,d? :number):number
{
    return a+b+c+d;
}
var s3=addition3(1,2,3,4);
var s4=addition3(1,2,1);
var s5=addition3(1,2,3,4);
var s6=addition3(1,2,3,4);
console.log(s3);
console.log(s4);
console.log(s5);
console.log(s6);