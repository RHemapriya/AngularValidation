class Employee{
    static empid:number;
    name:string;
    constructor(empid:number,name:string){
        Employee.empid=empid;
        this.name=name;
    }
    displayDetails(){
        return Employee.empid+" : "+this.name;
    }
}
Employee.empid=123;
var emp=new Employee(123,"Madhav");
console.log(emp.displayDetails());
