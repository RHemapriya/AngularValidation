let num=12;
let a1=[1,2,3,'a',true];
var x:number[];
x=[1,2,3,4];
x.push(10);
console.log(x);
for(let i in x)
{
    console.log(i);
}
console.log(num);
num=x.pop();
console.log(num);
let numberList: number[]=[1,2,3];
let numList:Array<number>=[1,2,3];
console.log(numberList);
console.log(numList);
console.log(x);
