import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateAccountComponent } from './create-account/create-account.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import { RouterModule,Routes } from '@angular/router';



const routes:Routes=[
  {
  path:'CreateAcc',
  component:CreateAccountComponent
  },
  {
  path:'Deposit',
  component:DepositComponent
  },
  {
  path:'WithDraw',
  component:WithdrawComponent
  },
  {
  path:'FundTrans',
  component:FundTransferComponent
  },
  {
  path:'ShowBal',
  component:ShowBalanceComponent
  },
  {
  path:'PrintTrans',
  component:PrintTransactionComponent
  },
 ];



@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
