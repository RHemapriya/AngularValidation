import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
valid:any;
name:string;
address:string;
pincode:number;
  constructor() { }

  ngOnInit() {
    this.valid={
      name:this.name,
      address:this.address,
      pincode:this.pincode
    }
  }

}
