import { ValidRoutingModule } from './valid-routing.module';

describe('ValidRoutingModule', () => {
  let validRoutingModule: ValidRoutingModule;

  beforeEach(() => {
    validRoutingModule = new ValidRoutingModule();
  });

  it('should create an instance', () => {
    expect(validRoutingModule).toBeTruthy();
  });
});
