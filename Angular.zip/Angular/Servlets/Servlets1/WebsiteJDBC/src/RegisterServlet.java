

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class RegisterServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter out=response.getWriter();
		String username=request.getParameter("uname");
		String password=request.getParameter("pass");
		String name=request.getParameter("name1");
		try{
			ServletContext context=getServletContext();
			String driver=context.getInitParameter("Servletdriverclass");
			String url1=context.getInitParameter("url");
			String user=context.getInitParameter("username");
			String pass=context.getInitParameter("password");
			
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url1,user,pass);
		
		PreparedStatement stmt=conn.prepareStatement("insert into gmail values(?,?,?)");
		stmt.setString(1,username);
		stmt.setString(2,password);
		stmt.setString(3, name);
		ResultSet result=stmt.executeQuery();

		if(result.next())
		{
			RequestDispatcher rd=request.getRequestDispatcher("Login.html");
		    rd.include(request, response);
		 
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Index.html");
			rd.include(request, response);
			out.println("PLEASE ENTER VALID CREDENTIALS");
		}
		conn.close();}
		catch(Exception e)
		{
			System.out.println(e);
		}
			
		
	}
}
