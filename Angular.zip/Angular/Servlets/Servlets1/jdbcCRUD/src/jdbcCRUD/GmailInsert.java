package jdbcCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class GmailInsert {
	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg412","training412");
		
		Scanner scan=new Scanner(System.in);
	    System.out.println("Enter the Username");
	    String uname=scan.next();
	    System.out.println("Enter the Password");
	    String upass=scan.next();
	    System.out.println("Enter the Name");
	    String name=scan.next();
		
		PreparedStatement stmt=conn.prepareStatement("insert into gmail values(?,?,?)");
		stmt.setString(1, uname);
		stmt.setString(2,upass);
		stmt.setString(3, name);
		int result=stmt.executeUpdate();

		if(result>0)
		{
		System.out.println("Registered successfully");
		}
		else
		{
		System.out.println("Registered failed");
		}
		conn.close();

	}

}
