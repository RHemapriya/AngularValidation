package jdbcCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class GmailSql1 {
	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg412","training412");
		
		Scanner scan=new Scanner(System.in);
	    System.out.println("Enter the Username");
	    String uname=scan.next();
	    System.out.println("Enter the Password");
	    String upass=scan.next();
	    
		
		
		
		PreparedStatement stmt=conn.prepareStatement("select * from gmail where username=? and password=?");
		stmt.setString(1, uname);
		stmt.setString(2,upass);
		ResultSet result=stmt.executeQuery();

		
		if(result.next())
		{
		System.out.println("Login Success");
		}
		else
		{
		System.out.println("Login failed");
		}
		conn.close();

	}
	}


