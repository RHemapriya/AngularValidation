function add(x, y) {
    return x + y;
}
var sum = function (x, y) {
    return x + y;
};
add(2, 3);
sum(5, 3);
console.log(add);
console.log(sum);
var sum1 = function (x, y) { return x + y; };
sum1(10, 10);
console.log(sum1);
var sum2 = function (x, y) { return x + y; };
sum2(10, 10);
console.log(sum2);
var sum3 = function (x, y) { return x + y; };
sum3(10, 10);
console.log(sum3);
var sum4 = function () { return console.log("Function is perform various ways"); };
sum4();
