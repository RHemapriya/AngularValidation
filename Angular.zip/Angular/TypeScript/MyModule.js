"use strict";
exports.__esModule = true;
var Employee = /** @class */ (function () {
    function Employee(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    Employee.prototype.showDetails = function () {
        return this.firstname + ", " + this.lastname;
    };
    return Employee;
}());
exports.Employee = Employee;
var Student = /** @class */ (function () {
    function Student(rollNo, name) {
        this.rollNo = rollNo;
        this.name = name;
    }
    Student.prototype.showDetails = function () {
        return this.rollNo + ", " + this.name;
    };
    return Student;
}());
exports.Student = Student;
