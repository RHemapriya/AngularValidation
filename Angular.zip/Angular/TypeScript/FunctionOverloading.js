function add(x, y, z) {
    var result;
    if (typeof x == "number" && typeof y == "number" && typeof z == "number") {
        result = x + y + z;
    }
    else {
        result = x + y + " " + z;
    }
    return result;
}
var result1 = add(2, 3, 1);
var result2 = add("Hi", "Hello", "Welcome");
console.log(result1);
console.log(result2);
