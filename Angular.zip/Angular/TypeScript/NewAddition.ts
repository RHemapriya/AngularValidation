function add(x:number,y:number):number{
    return x+y;
}
let sum=function(x:number,y:number):number{
    return x+y;
}
add(2,3);
sum(5,3);
console.log(add);
console.log(sum);
let sum1=(x:number,y:number)=>x+y;
sum1(10,10);
console.log(sum1);
let sum2=(x:number,y:number)=>{return x+y};
sum2(10,10);
console.log(sum2);
let sum3=(x,y)=>x+y;
sum3(10,10);
console.log(sum3);
let sum4=()=>console.log("Function is perform various ways");
sum4();
