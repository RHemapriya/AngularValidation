let firstname:string="International Business Machine";
let site:string='www.ibm.com';
//String concatenation
let str='Hello, my name is '+firstname+' and my site is '+site;
console.log(str);
//String interpolation and multiline
let str2=`Hello, my name is ${firstname} and my site is ${site}`;
console.log(str2);