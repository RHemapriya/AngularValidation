import{Student,Employee} from "./MyModule";
let st=new Student(1,"Madhav");
let result1=st.showDetails();
console.log("Student Details: "+result1);
let emp=new Employee("Kannan","Hello");
let result2=emp.showDetails();
console.log("Employee Details: "+result2);