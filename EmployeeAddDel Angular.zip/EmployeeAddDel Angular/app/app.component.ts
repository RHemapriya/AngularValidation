import { Component } from '@angular/core';

@Component({
  selector: 'app-module2',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Module2';
}
